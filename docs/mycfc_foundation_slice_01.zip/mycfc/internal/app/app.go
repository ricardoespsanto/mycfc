package app

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/alexedwards/scs/pgxstore"
	"github.com/alexedwards/scs/v2"
	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	"github.com/cfcoimbra/mycfc/internal/config"
	"github.com/cfcoimbra/mycfc/internal/httpx"
	"github.com/cfcoimbra/mycfc/internal/storage"
	"github.com/gorilla/csrf"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Application struct {
	Config       config.Config
	Logger       *slog.Logger
	Location     *time.Location
	Pool         *pgxpool.Pool
	Sessions     *scs.SessionManager
	SessionStore *pgxstore.PostgresStore
	ObjectStore  storage.ObjectStore
	Server       *http.Server
}

func New(ctx context.Context) (*Application, error) {
	cfg, err := config.Load()
	if err != nil {
		return nil, err
	}

	logger := newLogger(cfg, os.Stdout)
	slog.SetDefault(logger)

	location, err := time.LoadLocation("Europe/Lisbon")
	if err != nil {
		return nil, fmt.Errorf("load Europe/Lisbon: %w", err)
	}

	poolConfig, err := pgxpool.ParseConfig(cfg.DatabaseURL.Value())
	if err != nil {
		return nil, errors.New("parse DATABASE_URL")
	}
	poolConfig.MaxConns = cfg.DBMaxConns
	poolConfig.MinConns = cfg.DBMinConns
	poolConfig.MaxConnLifetime = cfg.DBMaxConnLifetime
	poolConfig.MaxConnIdleTime = cfg.DBMaxConnIdleTime
	poolConfig.HealthCheckPeriod = cfg.DBHealthCheckPeriod

	pool, err := pgxpool.NewWithConfig(ctx, poolConfig)
	if err != nil {
		return nil, errors.New("open database pool")
	}
	pingContext, cancelPing := context.WithTimeout(ctx, 5*time.Second)
	defer cancelPing()
	if err := pool.Ping(pingContext); err != nil {
		pool.Close()
		return nil, errors.New("database ping failed")
	}

	sessionStore := pgxstore.New(pool)
	sessions := scs.New()
	sessions.Store = sessionStore
	sessions.Lifetime = cfg.SessionLifetime
	sessions.IdleTimeout = cfg.SessionIdleTimeout
	sessions.Cookie.Name = "mycfc_session"
	sessions.Cookie.HttpOnly = true
	sessions.Cookie.Path = "/"
	sessions.Cookie.SameSite = http.SameSiteLaxMode
	sessions.Cookie.Secure = cfg.IsProduction()
	sessions.Cookie.Domain = cfg.CookieDomain

	awsCfg, err := awsconfig.LoadDefaultConfig(ctx, awsconfig.WithRegion(cfg.AWSRegion))
	if err != nil {
		sessionStore.StopCleanup()
		pool.Close()
		return nil, fmt.Errorf("load AWS configuration: %w", err)
	}
	s3Client := s3.NewFromConfig(awsCfg, func(options *s3.Options) {
		options.UsePathStyle = cfg.S3ForcePathStyle
		if cfg.S3Endpoint != "" {
			options.BaseEndpoint = aws.String(cfg.S3Endpoint)
		}
	})
	objectStore := storage.NewS3Store(s3Client, cfg.S3BucketName)

	csrfKey, err := cfg.CSRFAuthKey()
	if err != nil {
		sessionStore.StopCleanup()
		pool.Close()
		return nil, err
	}

	router := newRouter(pool, sessions)
	csrfMiddleware := csrf.Protect(
		csrfKey,
		csrf.CookieName("mycfc_csrf"),
		csrf.Path("/"),
		csrf.Secure(cfg.IsProduction()),
		csrf.SameSite(csrf.SameSiteLaxMode),
		csrf.MaxAge(int(cfg.SessionLifetime.Seconds())),
		csrf.ErrorHandler(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.WriteHeader(http.StatusForbidden)
			_, _ = w.Write([]byte(`<!doctype html><html lang="pt-PT"><title>Pedido recusado</title><main id="conteudo-principal"><h1>Pedido recusado</h1><p>Atualize a página e tente novamente.</p></main></html>`))
		})),
	)

	trusted, err := cfg.TrustedProxyCIDRs()
	if err != nil {
		sessionStore.StopCleanup()
		pool.Close()
		return nil, err
	}

	handler := httpx.Chain(
		router,
		httpx.RecoveryMiddleware(logger),
		httpx.RequestIDMiddleware(),
		httpx.TrustedProxyMiddleware(trusted),
		httpx.SecurityHeadersMiddleware(cfg.IsProduction()),
		httpx.AccessLogMiddleware(logger),
		func(next http.Handler) http.Handler { return sessions.LoadAndSave(next) },
		func(next http.Handler) http.Handler { return csrfMiddleware(next) },
	)

	server := &http.Server{
		Addr:              cfg.HTTPAddress(),
		Handler:           handler,
		ReadHeaderTimeout: cfg.HTTPReadHeaderTimeout,
		ReadTimeout:       cfg.HTTPReadTimeout,
		WriteTimeout:      cfg.HTTPWriteTimeout,
		IdleTimeout:       cfg.HTTPIdleTimeout,
	}

	return &Application{
		Config:       cfg,
		Logger:       logger,
		Location:     location,
		Pool:         pool,
		Sessions:     sessions,
		SessionStore: sessionStore,
		ObjectStore:  objectStore,
		Server:       server,
	}, nil
}

func (a *Application) Close() {
	if a.SessionStore != nil {
		a.SessionStore.StopCleanup()
	}
	if a.Pool != nil {
		a.Pool.Close()
	}
}

func (a *Application) Run(ctx context.Context) error {
	serverErrors := make(chan error, 1)
	go func() {
		a.Logger.Info("server starting", "address", a.Server.Addr, "version", a.Config.AppVersion)
		err := a.Server.ListenAndServe()
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			serverErrors <- err
			return
		}
		serverErrors <- nil
	}()

	signalContext, stop := signal.NotifyContext(ctx, syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	select {
	case err := <-serverErrors:
		if err != nil {
			return fmt.Errorf("serve HTTP: %w", err)
		}
		return nil
	case <-signalContext.Done():
		a.Logger.Info("shutdown requested")
	}

	shutdownContext, cancel := context.WithTimeout(context.Background(), a.Config.ShutdownTimeout)
	defer cancel()
	if err := a.Server.Shutdown(shutdownContext); err != nil {
		return fmt.Errorf("shutdown HTTP server: %w", err)
	}
	if err := <-serverErrors; err != nil {
		return fmt.Errorf("serve HTTP during shutdown: %w", err)
	}
	return nil
}
