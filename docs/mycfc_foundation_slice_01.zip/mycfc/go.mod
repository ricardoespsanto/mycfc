module github.com/cfcoimbra/mycfc

go 1.26.0

toolchain go1.26.5

require (
	github.com/alexedwards/scs/pgxstore v0.0.0-20251002162104-209de6e426de
	github.com/alexedwards/scs/v2 v2.9.0
	github.com/aws/aws-sdk-go-v2 v1.36.3
	github.com/aws/aws-sdk-go-v2/config v1.29.9
	github.com/aws/aws-sdk-go-v2/service/s3 v1.79.1
	github.com/caarlos0/env/v11 v11.4.1
	github.com/gorilla/csrf v1.7.3
	github.com/jackc/pgx/v5 v5.7.5
	golang.org/x/image v0.25.0
)
